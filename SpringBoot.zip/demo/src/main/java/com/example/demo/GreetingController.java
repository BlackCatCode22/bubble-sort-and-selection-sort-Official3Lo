package com.example.demo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@ControllerAdvice
//@Controller
//@ResponseBody
public class GreetingController {
    @ExceptionHandler(Exception.class)
    @RequestMapping(path = "/greeting", method = RequestMethod.POST)
    public String getGreeting(){
        return "xxxxxxxxxxxxxxxxx";
    }
}
