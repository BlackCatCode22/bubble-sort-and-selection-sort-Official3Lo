package com.example.demo;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;


@RestController
public class DemoController {
    private Map<String Photo> db = new HashMap<>(){{
        put("1", new Photo("1","hello,jpg"));
    }};
    private List<Photo> db =List.of(new Photo("1","hello.jpg"));
    @GetMapping("/")
    public String hello(){
        return "hi";
    }
    @GetMapping("/photos")
    public List<Photo> get(){
        return db;
    }
    @GetMapping("/photos/{id}")
    public List<Photo> get(@PathVariable String id){

        return db;
    }
}
